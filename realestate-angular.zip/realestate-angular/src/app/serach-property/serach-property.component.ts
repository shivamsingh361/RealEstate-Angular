import { Component, OnInit } from '@angular/core';
import { PropertyapiService } from '../propertyapi.service'
import { Property } from '../property'
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { ViewService } from './view.service';


@Component({
  selector: 'app-serach-property',
  templateUrl: './serach-property.component.html',
  styleUrls: ['./serach-property.component.css']
})

export class SerachPropertyComponent implements OnInit {
  propType = { 1: "ALL", 2: "HOUSE", 3: "FLAT", 4: "RENTAL", 5: "PLOT", 6: "HOSTEL" }
  propPrice = { 1: 0, 2: 5000, 3: 10000, 4: 20000, 5: 50000, 6: 100000 }
  city = []
  allProperty = []
  propertyList: Property[];
  propTypeSelected
  propPriceSelected
  propCitySelected

  constructor(private propertyApi: PropertyapiService, private service: ViewService) {
    this.getAllCities();
  }

  ngOnInit() {
    this.propertyApi.getAllProperty().subscribe((data: any[]) => {
      console.log("Data is = " + data);
      this.allProperty = data;
    }, error => {
      this.propertyApi.changeMessage(error)
    })
  }

  viewProp(prop: Property) {
    this.service.view(prop);
  }

  getAllCities() {
    for (let index = 0; index < this.allProperty.length; index++) {
      const element = this.allProperty[index].city;
      if (!this.city.includes(element, 0)) { this.city.push(element) }
      else { }
    }
  }

  onClickType() {
    this.getAllCities();
    this.propertyList = [];
    if (this.propTypeSelected != 1) {
      for (let index = 0; index < this.allProperty.length; index++) {
        const element = this.allProperty[index];
        if (element.propType.match(this.propType[this.propTypeSelected])) {
          this.propertyList.push(element);
        }
      }
    }
    else {
      this.propertyList.push(...this.allProperty);
    }
  }

  onClickPrice() {
    var temp = [];
    this.onClickType();
    if (this.propPriceSelected != 1) {
      for (let index = 0; index < this.propertyList.length; index++) {
        if (
          parseFloat(this.propertyList[index].propPrice) > this.propPrice[this.propPriceSelected - 1]
          &&
          parseFloat(this.propertyList[index].propPrice) <= this.propPrice[this.propPriceSelected]) {
          temp.push(this.propertyList[index]);
        }
      }
      this.propertyList = []
      this.propertyList.push(...temp);
    }
  }

  onClickCity() {
    var temp = [];
    this.onClickPrice();
    if (this.propCitySelected != -1) {
      for (let index = 0; index < this.propertyList.length; index++) {
        if (this.propertyList[index].city.match(this.city[this.propCitySelected])) { temp.push(this.propertyList[index]) }
      }
      this.propertyList = []
      this.propertyList.push(...temp);
    }
  }
  onClickSubmit(data) {
    //alert("Filter vALUES: " + this.propType[data.propType] + "\n"+ this.propPrice[data.propPrice] + "\n"+ data.city + "\n");
    this.onClickType();
    this.onClickPrice();
    this.onClickCity();
  }
}
