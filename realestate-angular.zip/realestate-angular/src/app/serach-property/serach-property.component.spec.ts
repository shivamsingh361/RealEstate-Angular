import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SerachPropertyComponent } from './serach-property.component';

describe('SerachPropertyComponent', () => {
  let component: SerachPropertyComponent;
  let fixture: ComponentFixture<SerachPropertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SerachPropertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SerachPropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
