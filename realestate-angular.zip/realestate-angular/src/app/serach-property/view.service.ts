import { Injectable,EventEmitter } from '@angular/core';
import { Property } from '../property';

@Injectable({
  providedIn: 'root'
})
export class ViewService {
  $viewProperty = new EventEmitter();

  constructor() { }
  
  view(prop:Property){
    this.$viewProperty.emit(prop);
  }

}
