import { Component, OnInit } from '@angular/core';
import { PropertyapiService } from '../propertyapi.service';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-add-image',
  templateUrl: './add-image.component.html',
  styleUrls: ['./add-image.component.css']
})
export class AddImageComponent implements OnInit {

  constructor(private _propService: PropertyapiService, private sanitizer: DomSanitizer) { }

  ngOnInit() {
  }

  title = 'ImageUploaderFrontEnd';

  public selectedFile;
  public event1;
  imgURL: any;
  receivedImageData: any;
  base64Data: any;
  convertedImage: any;
  image: any
  propId: any

  public onFileChanged(event) {
    console.log(event);
    this.selectedFile = event.target.files[0];

    // Below part is used to display the selected image
    let reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event2) => {
      this.imgURL = reader.result;
    };
  }


  // This part is for uploading
  onUpload() {
    const uploadData = new FormData();
    if ((this.selectedFile.size / 1024) > 64.00){
      this._propService.changeMessage("File Size Must Be Less Then 64 KB");
    }
      else {
      uploadData.append('myFile', this.selectedFile, this.selectedFile.name);
      this._propService.putImage(uploadData, this.propId)
        .subscribe(
          res => {
            //console.log(res);
            this.receivedImageData = res;
            this.base64Data = this.receivedImageData.pic;
            this.convertedImage = 'data:image/jpeg;base64,' + this.base64Data;
            this.image = this.sanitizer.bypassSecurityTrustUrl(this.convertedImage);
          },
          err => {
            console.log('Error Occured during saving: ' + err);
            this._propService.changeMessage(err);
          }
        );
    }
  }
}
