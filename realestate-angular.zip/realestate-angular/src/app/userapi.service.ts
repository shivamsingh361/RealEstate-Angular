import { Injectable, EventEmitter} from '@angular/core';
import {HttpClient, HttpErrorResponse } from '@angular/common/http'
import { throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserapiService {

  private REST_API_SERVER = "http://localhost:3305/api";
  constructor(private httpClient: HttpClient) { }

  handleError(error: HttpErrorResponse){
    let errorMessage = 'Unknown Error!';
    if(error.error instanceof ErrorEvent){
      errorMessage = `Error: ${error.error.message}`;
    }
    else{
      if(error.status == 0)
        errorMessage = `Server Not Accessible! It Might be off.`
      else
        errorMessage = `${error.status}:${error.message}`;
    }
    //window.alert(errorMessage);
    return throwError(errorMessage);
  }
  
  
  public login(id, pass) {
    return this.httpClient.post(this.REST_API_SERVER+`/login`,{"userId":id, "pass":pass})
    .pipe(retry(3), catchError(this.handleError));
  }
  
  public getAllUserIds(){
    return this.httpClient.get(this.REST_API_SERVER+`/alluserids`).pipe(retry(3), catchError(this.handleError));
  }

  public addUser(_user:User) {
    return this.httpClient.post(this.REST_API_SERVER+`/register`,_user).pipe(retry(3), catchError(this.handleError));
  }

  public updateUser(_user:User) {
    return this.httpClient.post(this.REST_API_SERVER+`/updateuser`,_user).pipe(retry(3), catchError(this.handleError));
  }

  public deleteUser(id:any) {
    return this.httpClient.post(this.REST_API_SERVER+`/deleteuser/${id}`,null).pipe(retry(3), catchError(this.handleError));
  }

}
