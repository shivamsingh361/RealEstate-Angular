import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

import { throwError, BehaviorSubject } from 'rxjs';
import { retry, catchError } from 'rxjs/operators'
import { Property } from './property';
import { InterestLog } from './interestLog';
import { error } from '@angular/compiler/src/util';
import { ifError } from 'assert';
import { ReturnStatement } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class PropertyapiService {
  private REST_API_SERVER = "http://localhost:3305/api";
  private errorMsg = new BehaviorSubject('');
  currErrorMsg = this.errorMsg.asObservable();

  constructor(private httpClient: HttpClient) { }

  handleError(error: HttpErrorResponse) {
    let errorMessage = 'Unknown Error!';
    if (error.error instanceof ErrorEvent)
      errorMessage = `Error: ${error.error.message}`;
    else {
      if (error.status == 0)
        errorMessage = `Server Not Accessible! It Might be off.`
      else
        errorMessage = `${error.status}: ${error.message}`; return throwError(errorMessage);
    }
  }

  changeMessage(message: string) {
    this.errorMsg.next(message);
  }

  public getAllProperty() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      })
    };

    return this.httpClient.get(this.REST_API_SERVER + "/allproperties", httpOptions).pipe(catchError(this.handleError));
  }
  public getPropertyByType(type: any) {
    return this.httpClient.get(this.REST_API_SERVER + `/getpropertybygenre/${type}`).pipe(catchError(this.handleError));
  }
  public getPropertyById(id) {
    return this.httpClient.get(this.REST_API_SERVER + `/getproperty/${id}`).pipe(retry(1), catchError(this.handleError));
  }
  public deleteProperty(id) {
    return this.httpClient.post(this.REST_API_SERVER + `/deleteproperty/${id}`, null).pipe(retry(1), catchError(this.handleError));
  }
  public addProperty(_property: Property) {
    return this.httpClient.post(this.REST_API_SERVER + `/addproperty`, _property).pipe(retry(1), catchError(this.handleError));
  }


  ////////////////////////////////// /////////////////////////////////////////////////////
  public putImage(uploadData, propId) {
    return this.httpClient.post(this.REST_API_SERVER + `/upload/${propId}`, uploadData).pipe(retry(1), catchError(this.handleError));
  }
  public getImage(id) {
    return this.httpClient.get(this.REST_API_SERVER + `/getImageByPropId/${id}`).pipe(retry(3), catchError(this.handleError));
  }
  ////////////////////////////////// ////////////////////////////////////////////////////


  public addInterest(_interestlog: InterestLog) {
    return this.httpClient.post(this.REST_API_SERVER + `/addinterest`, _interestlog).pipe(retry(3), catchError(this.handleError));
  }
  public getAllInterest() {
    return this.httpClient.get(this.REST_API_SERVER + "/allinterest").pipe(retry(3), catchError(this.handleError));
  }
}
