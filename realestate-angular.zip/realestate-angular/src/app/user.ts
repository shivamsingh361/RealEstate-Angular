export class User {
    userId: any
    firstName: any
    lastName: any
    contact: any
    city: any
    pass: any
    constructor(userId: any, firstName: any, lastName: any, contact: any, city: any, pass: any) {
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.contact = contact;
        this.city = city;
        this.pass = pass;
    }
}