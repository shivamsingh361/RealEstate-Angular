import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MainComponent } from './main/main.component';
import {SerachPropertyComponent} from './serach-property/serach-property.component'
const routes: Routes = [
  {path:'main',component:MainComponent},
  {path:'search-property', component:SerachPropertyComponent},
  {path:'', component:MainComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
