export class Property {
    propId: any;
    propPrice: any;
    propDescription: any;
    propType: any;
    houseNo: any;
    district: any;
    pin: any;
    city: any;
    state: any;
    landmark: any;
    ownerContact: any;

    constructor(id: any,
        propPrice: any,
        propDescription: any,
        propType: any,
        houseNo: any,
        district: any,
        pin: any,
        city: any,
        state: any,
        landmark: any,
        ownerContact: any) {
        this.propId = id;
        this.propPrice = propPrice;
        this.propDescription = propDescription;
        this.propType = propType;
        this.houseNo = houseNo;
        this.district = district;
        this.pin = pin;
        this.city = city;
        this.state = state;
        this.landmark = landmark;
        this.ownerContact = ownerContact;
    }
}