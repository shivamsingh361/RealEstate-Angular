import { Component, OnInit } from '@angular/core';
import { UserapiService } from '../userapi.service';
import { User } from '../user';
import { PropertyapiService } from '../propertyapi.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  user = null
  errorMessage = ""

  constructor(private _userApiService: UserapiService, private _propertyApiService: PropertyapiService) {
  }

  ngOnInit() {
    this._propertyApiService.currErrorMsg.subscribe(msg => {
      this.errorMessage = msg;
    })
  }


  // logIn() {
  //   this._userApiService.login("davick@gmail.com", "password").subscribe((data: any) => {
  //     console.log(data);
  //     this.user = data;
  //   })
  //   console.log("Log In As:\n")
  //   console.log(this.user);
  // }
}
