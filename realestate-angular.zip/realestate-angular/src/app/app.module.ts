import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import { SerachPropertyComponent } from './serach-property/serach-property.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule} from '@angular/common/http';
import { ViewPropertyComponent } from './view-property/view-property.component';
import { AddImageComponent } from './add-image/add-image.component'
import { MyMaterialModule } from  './material.module';
import { FileSizePipe } from './file-size.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    SerachPropertyComponent,
    ViewPropertyComponent,
    AddImageComponent,
    FileSizePipe
  ],
  imports: [
    MyMaterialModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
