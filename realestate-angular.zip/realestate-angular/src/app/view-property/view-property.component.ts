import { Component, OnInit } from '@angular/core';
import { ViewService } from '../serach-property/view.service';
import { Property } from '../property';
import { PropertyapiService } from '../propertyapi.service';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-view-property',
  templateUrl: './view-property.component.html',
  styleUrls: ['./view-property.component.css']
})
export class ViewPropertyComponent implements OnInit {
property:Property = null
eligibleToView = false
imgURL: any;
receivedImageData: any;
base64Data: any;
convertedImage: any;
images:any[]

  constructor(private _viewService: ViewService,
     private _propService:PropertyapiService,
     private sanitizer: DomSanitizer) { 
  }

  ngOnInit() {
    this._viewService.$viewProperty
      .subscribe((data:Property) => {
        this.property = data;
        this.eligibleToView = false;
        this.images = []
        this.getImage(this.property.propId)
      })
  }

  getImage(prop_id){
    this._propService.getImage(prop_id)
    .subscribe( (data :any[]) => {
      this.images = []
      for (let index = 0; index < data.length; index++) {
        const res = data[index];
        //console.log("rendering Image "+index+" Started!");
        this.receivedImageData = res;
        this.base64Data = this.receivedImageData.pic;
        this.convertedImage = 'data:image/jpeg;base64,' + this.base64Data;
        this.images.push(this.sanitizer.bypassSecurityTrustUrl(this.convertedImage));
        //console.log("rendering Image "+index+" Ended!");
      }
    },
    err => {console.log('Error Occured during fetching: ' + err+ " for propID = "+prop_id)
            this._propService.changeMessage("No Image available for this property!");
  })
  }

  onClickContactOwner(){
    this.eligibleToView = true;
  }

  showInterestInProperty(){
    console.log("You Showed Interest in this Property!");
  }
}
