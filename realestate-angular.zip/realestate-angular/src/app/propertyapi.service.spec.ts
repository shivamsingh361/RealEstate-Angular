import { TestBed } from '@angular/core/testing';

import { PropertyapiService } from './propertyapi.service';

describe('PropertyapiService', () => {
  let service: PropertyapiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PropertyapiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
