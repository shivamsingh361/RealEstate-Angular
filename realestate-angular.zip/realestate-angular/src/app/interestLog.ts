export class InterestLog{
    userId: any
    timestamp: Date
    city: any
    propId: any
	constructor( userId:any, timestamp:Date, city:any, propId:any) {
		this.userId = userId;
		this.timestamp = timestamp;
		this.city = city;
		this.propId = propId;
	}
}